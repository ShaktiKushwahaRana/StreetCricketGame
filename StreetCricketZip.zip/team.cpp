#include "team.h"		// "player.h", <string>, <vector>


Team::Team() {

	totalRunsScored = 0;
	wicketsLost = 0;
	totalBallsBowled = 0;
}
